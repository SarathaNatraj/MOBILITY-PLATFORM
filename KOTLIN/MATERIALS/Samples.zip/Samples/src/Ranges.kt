fun main(){
    // var range = start .. end
    println("Start and End inclusive")
    // in 1.. 5 start and end is inclusive
    for(i in 1..5){
        print(i) //1, 2,3,4,5
    }
    println("Start is only inclusive")

    // 1, 2,3, 4 until (n-1) start is inclusive end is exclusive
    for(i in 1 until 5){
        print(i) //1,2,3,4
    }
    println(" Range with not equal to")
    for(i in 1 .. 10){
        if( i != 5){
            print(i)
        }
    }
    println(" Decrement")
    for( i in 5 downTo 1){
        print(i)
    }

    println(" Step 2")
    for( i in 1 .. 10 step 2){
        print(i)
    }

    println(" ")
    //check if a value belongs to range
    val x = 25
    if(x in 1..10){
        println("$x is in range")
    }else{
        println("$x is not in range")
    }
}