package arrays


fun main(){
    //arrayOf
    val numbers = arrayOf(1,2,3,4) //integer array

    //Array class constructor
    val squares = Array(5){i -> i * i} //1,4,9,16

    var strings:Array<String> = arrayOf("Kotlin", "Java", "Swift")

    //Accessing Elements - index
    println(numbers[3])
//Accessing Elements - get
    println(strings.get(2))

    println(squares)
    //Iterating the array
    for(num in squares){
        println(num)
    }
    println(strings.size)
    println(numbers.isEmpty())
    println("Sorting ")
    strings.sort()

    for(str in strings){
        println(str)

    }
    println(" Reverse ")
    numbers.reverse()
    for(num in numbers){
        println(num)
    }
     val filtered = numbers.filter { it > 2 }
    println(filtered)
    //
}