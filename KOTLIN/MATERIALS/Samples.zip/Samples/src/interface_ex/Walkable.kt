package interface_ex

interface Walkable {
    fun walk()
}