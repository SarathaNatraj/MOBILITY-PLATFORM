package interface_ex

interface TransactionActions {
    fun getCatagory():String
    fun calculateTax():Double
}