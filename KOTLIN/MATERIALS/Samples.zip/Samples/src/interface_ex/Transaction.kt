package interface_ex

open class Transaction(var amount:Double, var date:String, var desc: String) {
    open fun displayTransaction(){
        println("Date: $date | Description: $desc | Amount : $amount")

    }
}
