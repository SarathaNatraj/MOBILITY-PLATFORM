package interface_ex

class Animal : Movable, Walkable {
    override fun move() {
       println(" animal is movable")
    }

    override fun walk(){
        println(" animal is walkable")
    }
}

fun main(){
    val animal = Animal()
    animal.move()
    animal.walk()

    val person = Person()
    person.walk()
}