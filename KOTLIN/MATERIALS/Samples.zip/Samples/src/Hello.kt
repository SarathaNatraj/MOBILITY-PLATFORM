fun main(){
    var i:Int = 0
    for (i in 0 .. 5){
        println("*")
    }
}