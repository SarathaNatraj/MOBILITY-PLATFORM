package nullability

data class Meeting(val id:Int, val canClose: Boolean=true){
    fun close() : Boolean{
        println(" Meeting is closed.")
        return true
    }
}

fun closeMeeting(m:Meeting?):Boolean{
    return if(m!!.canClose) m.close()
            else return false
}
//?. safe call operator or !!. not - null assertion operator
//?: elvis operator or null coalescing operator

fun main(){
    //val m:Meeting? = null //null object

    var newMeeting= Meeting(1) //normal object

    //if m is not newMeeting = m, m is null, newMeeting = new Meeting() -> ?:
  //  closeMeeting(newMeeting)

   // newMeeting = m

    closeMeeting(newMeeting)



    closeMeeting(null)
}