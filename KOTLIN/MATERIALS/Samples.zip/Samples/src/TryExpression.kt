fun main(){

    //Try Expression
    val divide = try {
        val a = 10
        val b = 0
        a/b //result will be this
    }catch (e:ArithmeticException){
        println("Arithmetic Exception")
        0 //result will be replaced with 0
    }

    println(divide)

    var result = try{
        val list= listOf(1,2,3)
        list[5]
    }catch (e:IndexOutOfBoundsException){
        println("Exception caught :${e.message}")
        -1
    }finally {
        println(" This block always executed")
    }
    println(result)
}