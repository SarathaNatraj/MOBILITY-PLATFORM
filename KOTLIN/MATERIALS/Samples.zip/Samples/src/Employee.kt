class Employee {
  private  var empName:String="" //
    var empNo:Int=1
    val empOrganization:String="Wipro"
    var emailAddress =""

    //secondary constructor
    constructor(){
        empName="Chaitanya";
        empNo=101
        emailAddress="chaitanya@gmail.com"

     //   empOrganization="HCL"
    }

    fun  printDetails():Boolean {
        println(empName)
        println(empNo)

        return true
    }
}

fun main(){
    val e = Employee() //object creation without new operator
    e.printDetails();
  //  println(e.empName) //getter method of empName
    println(e.empNo) //getter method of empNo
    println(e.empOrganization)
  //  e.empName="Niranjan" //setter method of empName property
    e.empNo=201 //setter method of empName property
   // println(e.empName) //getter method of empName
    println(e.empNo) //getter method of empNo
    println(e.empOrganization)
}