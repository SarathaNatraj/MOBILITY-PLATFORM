class Person(val name:String, val age:Int) {

    var city:String = "Unknown"

    lateinit var email: String

    fun initializeEmail(value:String){
        this.email=value
    }

    constructor(name:String, age:Int, city:String, email:String):this(name,age){
        this.city=city
//        initializeEmail(email)
       this.email=email
    }

    fun displayInfo(){
        println("Name : $name, Age: $age, City : $city, Email : $email")
    }

    override fun toString(): String {
        return "Person(name='$name', age=$age, city='$city')"
    }


}

fun main(){

    //Primary Constructor
   // val person = Person("Chaitanya", 22)
   // person.displayInfo()

    //println(person.toString())

    //Secondary constructor
    val person2=Person("Ravijeet", 22, "Mumbai","ravijeet@gmail.com")
   // person2.initializeEmail("ravijeet@gmail.com")
    person2.displayInfo()
}