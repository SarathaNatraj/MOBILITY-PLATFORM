package collections

data class Expense(val name:String, val amount:Double, val date:String)

fun main(){
    val expenses = listOf(Expense("Groceries", 200.0, "2025-01-01"),
        Expense("Rent", 1200.0, "2025-01-02"),
        Expense("Utilities", 150.0, "2025-01-03"),
        Expense("Dining Out", 100.0, "2025-01-04"),
        Expense("Subscriptions", 50.0, "2025-01-05"),
        Expense("Miscellaneous", 75.0, "2025-01-06"),
        Expense("Travel", 300.0, "2025-01-07"),
                Expense("Travel", 300.0, "2025-01-07")
    )

    val expenseSequence = expenses.asSequence()

    //Filter expenses greater than 100 and calculate total
    val totalAbove100 = expenseSequence
        .filter { it.amount > 100 }
        .map{it.amount}
        .sum()
    println(" Total Expenses above 100: $totalAbove100")

    //Group by Expenses and calculate sum for each name
    val catagoryTotal = expenses.asSequence()
        .groupBy { it.name }
        .mapValues { (_, expenses)-> expenses.sumOf{it.amount} }

    println(" Total Expenses by name :")
    catagoryTotal.forEach { (name, total) ->
        println("$name : $total")
    }

}