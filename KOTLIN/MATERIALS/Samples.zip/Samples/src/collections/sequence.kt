package collections

fun main(){
    //from collection
    val sequence = listOf(1,2,3,4,5).asSequence()
    println(sequence)

    //sequenceOf
    val sequence1 = sequenceOf(1,2,3)

    //generateSequence
    val sequence2 = generateSequence(3) { it+1 } //infinite

    var result= sequence
        .map{it *2}
        .filter { it > 5 }
        .toList()
    println(result)
}