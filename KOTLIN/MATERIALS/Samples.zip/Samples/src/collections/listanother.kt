package collections

fun main() {
    val numbers = listOf(10, 23, 3, 42, 51, 123, 6, 8, 99)

    val over50 = numbers.filter { it > 50 } //51,99,123
    println(" Over 50")
    for (item in over50) {
        println(item)
    }


    val multipliedValues = over50.map { it * 3 }
    println(" multipliedValues 50")

    for (item in multipliedValues) {
        println(item)
    }

    val newNumbers = numbers.filter { it > 50 }.map { (it * 3) }

    println(" Filter and map together")
    for (item in newNumbers) {
        println(item)
    }
    predicates()
}


fun predicates() {
    val numbers = listOf(10, 23, 3, 42, 51, 123, 6, 8, 99)

    val size = numbers.count()

    println("Size is: $size")

    val is100 = numbers.any { it > 99 }

    println("Number 100 or more: $is100")

    val allGreaterThanFifty = numbers.all { it > 50 }

    println("All > 50 : $allGreaterThanFifty")

    val set = setOf("Kotlin", "Java", "Swift")
    val containsJava = set.any{it == "Java"}
    println(containsJava)

    val users = listOf( User("Alice", false),
                        User("Bob", true),
                        User("Charlie", false))
    val hasActiveUser = users.any{it.isActive}
    println(hasActiveUser)

    //Syntax - mapOf
    // val map = mapOf(key1 to value1, key2 to value2)


    val map = mapOf(1 to "One", 2 to "Two", 3 to "Three")
    println(map)

    //Accessing the values
    val value= map[1]
    println(value)

    val value2= map.get(2)
    println(value2)

    //Check if value is present inside the map
    println(map.containsValue("Four"))
    println(map.containsValue("Two"))

    //iteration
    for((key, value) in map){
        println(" Key : $key, Value : $value")
    }

    println("Mutable :")
    val mutableMap = mutableMapOf(1 to "One", 2 to "Two")
    mutableMap[3] = "Three"
    mutableMap[2] = "Updated Two"
    println(mutableMap)

}

data class User(val name:String, val isActive: Boolean)

