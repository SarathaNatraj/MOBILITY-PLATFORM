package collections


/*
An Event Manager app tracks the following:

	A list of events (with details like name, date, and attendees).
	A map of users and the events they are registered for.
	A set of unique attendees for each event.
 */
import java.time.LocalDate

data class Event(
    val id:Int,
    val name:String,
    val date:LocalDate,
    val attendees : MutableSet<String> = mutableSetOf()
)

fun main(){
    //List of events
    val events = mutableListOf<Event>(
        Event(1, " Kotlin Workshop", LocalDate.of(2025, 1, 25)),
        Event(2, " AI Conference", LocalDate.of(2025, 2, 15)),
        Event(3, " Startup Workshop", LocalDate.of(2025, 3, 25)),
        )

    //Map of users and events
    val userRegistrations = mutableMapOf<String, MutableList<Event>>()

    //inner function - adding the attendees
    fun addAttendees(eventId:Int, attendee: String){
        val event = events.find { it.id == eventId }
        if(event == null){
            println(" Event with ID $eventId not found.")
        }else{
            event.attendees.add(attendee)
            userRegistrations.getOrPut(attendee) { mutableListOf() }.add(event)
            println(" Attendee '$attendee' added to '${event.name}'. ")
        }
    }

    //List all events

    //Get Attendees for specific event
    fun getEventAttendees(eventId:Int){
        val event = events.find { it.id == eventId }
        if(event != null){
            println(" Attendees for '${event.name}' : ${event.attendees.joinToString()}")
        }else{
            println(" Event with ID $eventId not found.")
        }
    }

    //Simulate adding attendees
    addAttendees(1, "Chaitanya")
    addAttendees(1, "Harish")
    addAttendees(2, "Lavanya")
    addAttendees(2, "Dhivya")
    addAttendees(3, "Ravijeet")
    addAttendees(3,"Subban")

    println(" Event Attendess for 1")
    getEventAttendees(1)

    println(" Event Attendess for 2")
    getEventAttendees(2)

    println(" Event Attendess for 3")
    getEventAttendees(3)

}