package classtypes

enum class EventType(val description: String){
    CONFERENCE(" A business or academic conference"),
    WORKSHOP("A interactive workshop session" ),
    WEBINAR("An online seminar or session"),
    SOCIAL(" A causal social gathering");

    fun displayEventType(){
        println(" Event Type: $name - $description")
    }
}

data class Event( val name:String,  val date:String, val type:EventType,  val location:String){
    fun displayEventDetails(){
        println(" Event name : $name")
        println(" Date : $date")
        println(" Location : $location")
        type.displayEventType()
    }
}

fun main(){
    val event1 = Event("Kotlin Conference 2025", "10/2/2025", EventType.CONFERENCE, "Online")

    val event2 = Event("Android Workshop", "10/3/2025", EventType.WORKSHOP, "New York")

    println(" Event 1 details ")
    event1.displayEventDetails()

    println(" Event 2 details ")
    event2.displayEventDetails()


}

