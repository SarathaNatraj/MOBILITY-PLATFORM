package classtypes

import inheritance.Expense


//Inline currency class
@JvmInline
value class Currency(val amount:Double){
    fun format() : String = "$${"%.2f".format(amount)}"
}

//Inline Transaction class
@JvmInline
value class TransactionID(val transId:String)

open class Transaction(var id: TransactionID, var amount:Currency, var date:String,  var desc:String){

    open fun displayTransaction(){
        println(" Transaction ID : ${id.transId}")
        println(" Amount : ${amount.format()}")
        println(" Date : $date")
        println(" Desc : $desc")
    }
}

class Income(id: TransactionID, amount:Currency,  date:String,  desc:String):Transaction(id, amount, date, desc){
    override fun displayTransaction() {
        super.displayTransaction()
        println(" Type : Income")
    }
}

class Expense(id: TransactionID, amount:Currency,  date:String,  desc:String):Transaction(id, amount, date, desc){
    override fun displayTransaction() {
        super.displayTransaction()
        println(" Type : Expense")
    }
}


fun main(){
    val income= Income(TransactionID("TXN123"), Currency(2500.00), "10/01/2025", "Salary")

    income.displayTransaction()

    val expense= Expense(TransactionID("TXN456"), Currency(500.0), "10/01/2025", "Grocery")

    expense.displayTransaction()

}