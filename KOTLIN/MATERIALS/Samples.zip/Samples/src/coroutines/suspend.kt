package coroutines



 suspend fun main() {

      val result1 =  performTask1()

      val result2=  performTask2()
    println("Result 1: $result1")
    println("Result 2: $result2")
}
suspend fun performTask1(): Int {
    Thread.sleep(10000L)  // Simulating a long-running task  , connecting db
    return 10
}
suspend fun performTask2(): Int {
    Thread.sleep(10000L) // Simulating another long-running task, downloading
    return 20
}