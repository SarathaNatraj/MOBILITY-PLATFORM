package coroutines

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.*

//Task 4: Use coroutines to handle simultaneous processing of importing and exporting transaction data without blocking the main thread.
data class Transaction(val id: Int, val amount:Double)


suspend fun processTransaction(transaction: Transaction) : String{
    println(" processTransaction starts on ${Thread.currentThread().name}")

    delay(1000)
    return "Transaction ${transaction.id} of amount: \$${transaction.amount}"

}

fun main()= runBlocking{

    val transactions = listOf(
        Transaction(1, 150.0),
        Transaction(2, 250.0),
        Transaction(3, 50.0),
        Transaction(4, 350.0),

    )
    println(" Starting the transaction processing")
    println(" Main program starts : ${Thread.currentThread().name}")
    var results = transactions.map{ transaction ->
        async ( Dispatchers.Default ){
            processTransaction(transaction)
        }
    }

    results.awaitAll().forEach { result ->
        println("Processed : $result")
    }

    println(" Main program ends : ${Thread.currentThread().name}")

}