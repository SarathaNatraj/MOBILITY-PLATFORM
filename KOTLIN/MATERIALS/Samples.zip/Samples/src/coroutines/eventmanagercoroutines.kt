package coroutines
//Task 2: Introduce coroutines to concurrently handle event bookings and cancellations.

import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.runBlocking

data class Event(val name:String,var availableSeat : Int)

class EventManager(private val events:List<Event>){
    suspend fun bookSeat(eventName: String){
        val event = events.find{it.name == eventName}
        if(event != null){
            if(event.availableSeat > 0){
                event.availableSeat--
                println("Successfully booked a seat for $eventName. Remaining seats: ${event.availableSeat}")
            }else{
                println("Booking failed: No seats available for $eventName.")
            }
        }else{
            println("Booking failed.: Event $eventName not found.")
        }
    }

    suspend fun cancelSeat(eventName: String){
        val event = events.find{it.name == eventName}
        if(event != null){
            event.availableSeat++
            println("Successfully canceled a seat for $eventName. Available seats: ${event.availableSeat}")
        }else{
            println(" Cancellation failed: Event $eventName not found.")
        }
    }
}


fun main() = runBlocking {
    val events = listOf(
        Event("Music Concert", 5),
        Event("Tech Conference", 15),
        Event("Art Exhibition", 7),
    )

    val eventManager = EventManager(events)

    val bookingAndCancellationJobs = listOf(
        async { eventManager.bookSeat("Music Concert") }, //4
        async { eventManager.bookSeat("Tech Conference") }, //14
        async { eventManager.cancelSeat("Music Concert") }, //5
        async { eventManager.bookSeat("Art Exhibition") }, //6
        async { eventManager.bookSeat("Music Concert") }, //4
        async { eventManager.cancelSeat("Tech Conference") }, //15
        async { eventManager.bookSeat("Tech Conference") }, //14
        async { eventManager.bookSeat("Non-Existent Event") }, // Test invalid event
        async { eventManager.cancelSeat("Art Exhibition") } //7
    )
    bookingAndCancellationJobs.awaitAll()
    println(" Final event Status: ")
    events.forEach {
        println("${it.name}: ${it.availableSeat}")
    }

}