package coroutines

import kotlinx.coroutines.*

fun main () = runBlocking{
    println(" Main program starts : ${Thread.currentThread().name}")

    //Async Tasks - function call
    val delayedTask1 = async { performTask1("Task 1", 1000L) }
    val delayedTask2 = async { performTask2("Task 2", 5000L) }


    //reults - await
    val result1 = delayedTask1.await()
    val result2 = delayedTask2.await()

    println(" Results : $result1 $result2")

    println(" Main program ends : ${Thread.currentThread().name}")


}

suspend fun performTask1(taskName:String,  sleep:Long): Int {
    println(" starts on ${Thread.currentThread().name}")
    delay(sleep)  // Simulating a long-running task  , connecting db
    println(" ends on ${Thread.currentThread().name}")
    println("$taskName result")
    return 10
}

suspend fun performTask2(taskName:String,  sleep:Long): Int {
    println(" starts on ${Thread.currentThread().name}")
    delay(sleep)  // Simulating a long-running task  , connecting db
    println(" ends on ${Thread.currentThread().name}")
    println("$taskName result")
    return 10
}