package objectsandcompanions

class FinanceUtils{
    companion object{
        fun formatAmount(amount:Double):String{
            return "$%.2f".format(amount)
        }
        fun convertCurrency(amount: Double, rate: Double): Double{
            return amount * rate
        }
    }
}
fun main(){
    val amount=1235.45689
    println(FinanceUtils.formatAmount(amount))

    val convertedAmount = FinanceUtils.convertCurrency(100.00, 0.85)
    println(convertedAmount)
    println(" Converted Amount : ${FinanceUtils.formatAmount(convertedAmount)}")
}