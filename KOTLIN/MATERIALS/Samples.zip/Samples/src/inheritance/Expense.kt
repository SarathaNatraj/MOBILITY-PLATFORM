package inheritance

class Expense(amount:Double, date:String, desc:String): Transaction(amount, date, desc)  {
    fun getCatagory():String{
        return if(amount>1000) "High Expense" else "Regular Expense"
    }

    override fun displayTransaction() {
        super.displayTransaction()
        println("Catagory : ${getCatagory()}")
    }
}

fun main(){

    //
    val income1:Transaction = Income(2500.00,"10/01/2025", "Salary")
    val income=Income(2500.00,"10/01/2025", "Salary")
    val expense=Expense(150.0,"10/01/2025","Shopping")
    println("Income details")
    income.displayTransaction()
    println("Expense details")
    expense.displayTransaction()

}