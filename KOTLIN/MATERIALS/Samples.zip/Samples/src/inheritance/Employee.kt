package inheritance

data class Employee(val age:Int)
