package inheritance

class Main{

}