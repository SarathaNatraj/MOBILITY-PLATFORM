package inheritance

class Income(amount:Double, date:String, desc:String): Transaction(amount, date, desc) {
    fun calculateTax():Double{
        return amount* 0.10
    }

    override fun displayTransaction() {
        super.displayTransaction()
        println("Tax : ${calculateTax()}")
    }
}