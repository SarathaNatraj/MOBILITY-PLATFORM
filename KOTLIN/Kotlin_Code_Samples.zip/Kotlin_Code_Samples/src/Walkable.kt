interface Walkable {
}