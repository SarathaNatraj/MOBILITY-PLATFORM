
import java.io.Serializable

class Claim : Serializable {

    var claimId: Int = 0
    var vehicleNumber: String? = null
        get() = "123xxx"
        set(value) {
            field = value
        }


    var accidentDetails: String? = null
    var claimAmount: String? = null
    var date: String? = null

    var imagePath: String? = null

    constructor(vehicleNumber: String?, accidentDetails: String?, claimAmount: String?, date: String?) {
        this.vehicleNumber = vehicleNumber
        this.accidentDetails = accidentDetails
        this.claimAmount = claimAmount
        this.date = date
    }

    constructor() : super()
}

fun main(){
    val c = Claim()
    println(c.vehicleNumber)
    c.vehicleNumber = "4569er89"
    println("vehicle Number: ${c.vehicleNumber}")
}