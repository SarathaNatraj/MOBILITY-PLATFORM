class Transaction(var amount:Double, var date:String, var desc: String) {
    init {
        amount=this.amount
        date=this.date
        desc=this.desc
        println(" init block executed.")
    }

    fun displayTransaction(){
        println("Date: $date | Description: $desc | Amount : $amount")

    }
}

fun main(){

    val t = Transaction(200.00, "10/01/2025", "Credit")
    println(t.date) // getter method of date property

    val t1 = Transaction(400.00, "11/01/2025", "Debit")
    t1.displayTransaction()
}