package interface_ex



class Income(amount:Double, date:String, desc:String): Transaction(amount, date, desc), TransactionActions {
    override fun getCatagory(): String {
        TODO("Not yet implemented")
    }

    override fun calculateTax():Double{
        return amount* 0.10
    }

    override fun displayTransaction() {
        super.displayTransaction()
        println("Tax : ${calculateTax()}")
    }
}