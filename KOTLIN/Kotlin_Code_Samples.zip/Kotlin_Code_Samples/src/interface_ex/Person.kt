package interface_ex

class Person : Walkable {
    override fun walk() {
        println(" Person is walkable")
    }
}