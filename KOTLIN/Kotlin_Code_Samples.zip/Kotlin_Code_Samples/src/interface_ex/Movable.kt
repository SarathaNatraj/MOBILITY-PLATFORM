package interface_ex

interface Movable {
    fun move()
}