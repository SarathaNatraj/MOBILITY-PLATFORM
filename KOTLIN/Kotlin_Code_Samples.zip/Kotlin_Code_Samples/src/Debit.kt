class Debit {
    var amount:Double=0.0
    var desc:String=""
    var date:String=""


    //secondary constructor
    constructor(){
        this.amount=100.0
        this.desc="Misc"
        this.date=""
    }

    fun displayTransaction(){
        println("Date: $date | Description: $desc | Amount : $amount")

    }

}

fun main(){
    val d = Debit();
    d.displayTransaction()
}