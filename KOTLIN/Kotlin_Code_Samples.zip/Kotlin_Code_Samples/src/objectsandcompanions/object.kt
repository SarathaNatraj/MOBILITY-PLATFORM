package objectsandcompanions


object EventManagerUtils{
    private val events =   mutableListOf<EventO>()


    fun addEvent(event: EventO){
        events.add(event)
        println("Event : '${event.name}' is added.")
    }
    fun displayEvents(){
        if(events.isEmpty()){
            println(" No Events available.")
        }else{
            println(" All Events")
            events.forEach {
                println("Name : ${it.name}, Type : ${it.type}")
            }
        }
    }

    fun findEventsByType(type:String):List<EventO>{
        return  events.filter { it.type.equals(type, ignoreCase = true) }
    }

}
data class EventO(val name:String, val type:String)
fun main(){
    EventManagerUtils.addEvent(EventO("Kotlin Conference","Conference" ))
    EventManagerUtils.addEvent(EventO("Android Workshop ","Workshop" ))
    EventManagerUtils.addEvent(EventO("Web Development Webinar","Webinar" ))

    EventManagerUtils.displayEvents()

    println(" Searching for Workshop events :")
    val workshops = EventManagerUtils.findEventsByType("Workshop")
    workshops.forEach { println(" Found Event : ${it.name} ") }




}