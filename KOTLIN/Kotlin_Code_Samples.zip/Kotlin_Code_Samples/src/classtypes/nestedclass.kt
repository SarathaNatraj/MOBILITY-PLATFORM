package classtypes

class PersonalFinanceTracker{

    //list of transactions
    private  val transactions = mutableListOf<TranscationN>()


    //Nested class -> without the inner keyword
   inner class TransactionUtils{
        fun calculateTotalAmount(transactions:List<TranscationN>):Double{
            return transactions.sumByDouble { it.amount }
        }
        fun countTransactionsByType(transactions:List<TranscationN>, type:String): Int{
            return transactions.count { it.type == type }
        }
    }

    fun addTransaction(amount: Double, type:String, desc:String){
        transactions.add(TranscationN(amount,desc, type))
    }
    fun displayTransaction(){
        println(" All Transactions")
        transactions.forEach {
            println("Amount : $${it.amount}, Type: ${it.type}, Desc: ${it.desc}")
        }
    }
    fun showSummary(){
        val utils = TransactionUtils()
        println(" Summary")
        println(" Total Amount : $${utils.calculateTotalAmount(transactions)}")
        println(" No of Income Txx : $${utils.countTransactionsByType(transactions, "Income")}")
        println(" No of Expense Txx : $${utils.countTransactionsByType(transactions, "Expense")}")

    }
    data class TranscationN (val amount:Double, val desc:String, val type:String)
}

fun main(){

    val financeTracker = PersonalFinanceTracker()

    financeTracker.addTransaction(100.0, "Income", "10/01/2025")
    financeTracker.addTransaction(200.0, "Expense", "01/01/2025")
    financeTracker.addTransaction(300.0, "Income", "10/01/2025")

    financeTracker.displayTransaction()

    financeTracker.showSummary()


    //val innerObj = OuterClass().innerClass() -> inner class object


}