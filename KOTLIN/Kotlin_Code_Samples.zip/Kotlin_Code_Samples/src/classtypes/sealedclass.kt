package classtypes

sealed class EventSealed{
    data class Conference( val name:String, val date:String, val location:String): EventSealed()
    data class WorkShop( val name:String, val date:String, val location:String): EventSealed()
    data class Webinar( val name:String, val date:String, val location:String): EventSealed()
    data class Social( val name:String, val date:String, val location:String): EventSealed()

    fun displayEventDetails(){
        when(this){
            is Conference -> {
                println(" Conference")
                println(" Name: $name")
                println(" Date : $date")
                println(" Location : $location")

            }
            is WorkShop -> {
                println(" WorkShop")
                println(" Name: $name")
                println(" Date : $date")
                println(" Location : $location")

            }
            is Webinar -> {
                println(" Webinar")
                println(" Name: $name")
                println(" Date : $date")
                println(" Location : $location")

            }
            is Social -> {
                println(" Social")
                println(" Name: $name")
                println(" Date : $date")
                println(" Location : $location")

            }
        }
    }

}

fun main(){
    val event1 = EventSealed.Conference("Kotlin Conference 2025", "10/2/2025", "Online")

    val event2 = EventSealed.WorkShop("Android Workshop", "10/3/2025", "New York")

    val event3 = EventSealed.Social("Mastering Kotlin", "05/05/2025", "Zoom")

    val events = listOf(event1, event2, event3)
    for( event in events){
        event.displayEventDetails()
        println()
    }


}
