fun main(){
    val number=15

    //Normal scenario - if -> JAVA
    if(number>0){
        println("Number is +ve")
    }else if(number == 0){
        println("Number is zero")
    }else{
        println("Number is -ve")
    }

    //Kotlin
    //if expression -> if you have single statement inside if condition
    var number1= 15
    var result = if(number1%2 == 0 ) "Even" else "Odd" //if expression
    println(result)

    //When -  is improvised switch statement
    val day = 5

    //Single condition
    when(day){
        1 -> println("Monday")
        2 -> println("Tuesday")
        3 -> println("Wednesday")
        else -> println("Invalid Day")
    }
try {
    //Multiple condition - Single line comment
    when (number) {
        1, 3, 5, 7, 9 -> println("Odd Number")
        2, 4, 6, 8, 10 -> println("Even Number")
        else -> println(" Unknown Number")
    }
}catch (e:Exception){ //catch(Exception e)
    e.printStackTrace()
}
/*
Multi line comments

 */


   // var str:String? = "xyz" //? null safety operator
    //?: -> ternary operator else part
  var str:String?="null"

    println(getLength(str))
    str=null
var i:Int=0

    do{
        println(i)
        i++
    }while (i<5)



}

fun getLength(str:String?): Int{
    return str?.length?:0
}