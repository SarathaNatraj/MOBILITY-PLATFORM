//primary constructor
class BankAccount(private val id: Int, var curBal: Double) {
    //doesnt have method body - method declaration
    //no definition - abstract method
     fun calculateInterest(): Double {
         return 10.00
     }


    //does have method body - method initialisation
    //fully defined method - concrete method
    fun deposit(amt: Float) {
        curBal += amt
    }

    fun withdraw(amt: Float) {
        curBal -= amt
    }
}





 fun main(){
     val bankAccount = BankAccount(1,3000.00 )
     println(bankAccount.calculateInterest(bankAccount.curBal))

 }