package inheritance

open class Animal {

    open fun diplay(){
        println(" Base Class - Hello Animal")
    }
}