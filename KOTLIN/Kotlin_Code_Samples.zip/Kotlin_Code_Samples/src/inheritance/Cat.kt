package inheritance

class Cat : Animal() {
    override fun diplay() {
        super.diplay()

        println(" Sub class display")
    }

}

fun main(){
    val cat = Cat()
    cat.diplay()
}