//extension function
//Syntax
//fun  ClassName.funtionName(parameters):<Return_Type>{
//}


fun BankAccount.calculateInterest(amt: Double): Double {
    return amt*10.00/100
}

fun String.toCamelcase(str:String):String{
    //Go with your logic
    return str
}